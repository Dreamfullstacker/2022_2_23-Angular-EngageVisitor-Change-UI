export class User {
    id;
    email;
    password;
    token;
    name;



}
