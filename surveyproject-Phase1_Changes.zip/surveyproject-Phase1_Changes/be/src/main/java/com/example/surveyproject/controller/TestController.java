package com.example.surveyproject.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

//	@Autowired
//	RepositoryAccess repositoryAccess;
//
//	@Autowired
//	ServiceAccess serviceAccess;

}
