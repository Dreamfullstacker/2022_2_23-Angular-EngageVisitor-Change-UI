package com.example.surveyproject.exception;

public class MemberShipException extends  RuntimeException{
    private static final long serialVersionUID = 1256L;

    public MemberShipException(String s) {
        super(s);
    }
}
