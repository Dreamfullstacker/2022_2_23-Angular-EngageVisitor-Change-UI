package com.example.surveyproject.model;

public enum USERTYPE {
    USER,TEMPLATE_CREATOR;
}
