package com.example.surveyproject.exception;

public class GeneralException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GeneralException(String s) {
		super(s);
	}
}