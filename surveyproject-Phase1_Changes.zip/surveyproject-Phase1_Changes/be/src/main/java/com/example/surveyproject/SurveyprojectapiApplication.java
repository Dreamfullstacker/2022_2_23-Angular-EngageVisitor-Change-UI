package com.example.surveyproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SurveyprojectapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SurveyprojectapiApplication.class, args);
	}

}
