export const environment = {
  production: true,
  // api: 'https://50.16.108.51/surveyprojectapi',
   
  //api: 'https://50.16.108.51:8443/surveyprojectapi',

 // api: 'https://survey.engagevisitor.com:8443/surveyprojectapi',
  //api: 'http://localhost:8080',
  api: 'https://survey.engagevisitor.com/surveyprojectapi',

  basepath: ''
};
