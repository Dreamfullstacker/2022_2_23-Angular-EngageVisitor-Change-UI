import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-sidenav',
  templateUrl: './form-sidenav.component.html',
  styleUrls: ['./form-sidenav.component.scss']
})
export class FormSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
