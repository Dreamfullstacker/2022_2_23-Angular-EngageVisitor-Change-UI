import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/model/user';
import { environment } from 'src/environments/environment';
import { ApiService } from '../../services/api.service';
import { AuthService } from '../../services/auth.service';
import { AllServicesService } from '../../services/all-services.service';
import { AppConst } from 'src/app/shared/app-const';
import { fadeInAnimation } from 'src/app/animation/fadein.animation';

@Component({
  selector: 'app-login',
  animations: [fadeInAnimation
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss', '../../shared/auth.scss']
})
export class LoginComponent implements OnInit {

  loginForm;
  loginFormLoader;
  appConst;
  constructor(
    private allServ: AllServicesService) {
    this.appConst = AppConst;
  }

  ngOnInit(): void {
    this.reset();

    this.initLoginForm();
  }

  login() {
    if (!this.loginForm.valid) {
      alert("Invalid form data");
    } else {
      this.loginFormLoader = true;
      this.allServ.api.login(this.getLoginFormPayload()).toPromise().then((data: any) => {
        let user: User = this.getLoginFormPayload();
        user.id = data.id;
        user.name = data.name;
        this.allServ.authServ.createLoginSession(user);
        this.allServ.router.navigateByUrl("form-listing");
        this.loginFormLoader = false;
      }).catch((e: any) => {
        this.allServ.toastr.error("Incorrect username or password", "LOGIN FAILED")
        this.loginFormLoader = false;
      });
    }
  }

  getLoginFormPayload(): User {
    let user: User = new User();
    user.email = this.loginForm.value.email;
    user.password = this.loginForm.value.password;
    return user;
  }

  initLoginForm() {
    this.loginForm = new FormGroup({
      email: new FormControl(!environment.production ? 'abc@gmail.com' : null, Validators.required),
      password: new FormControl(!environment.production ? '123456' : null, Validators.required)
    });
  }

  handleKeyPress(evn) {
    if (evn.keyCode == 13 && !this.loginFormLoader && this.loginForm.valid) {
      this.login();
    }
  }

  reset() {
    this.loginFormLoader = null;
  }

}
