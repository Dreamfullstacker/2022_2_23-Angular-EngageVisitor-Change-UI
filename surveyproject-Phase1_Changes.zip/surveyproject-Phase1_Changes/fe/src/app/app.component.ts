import { Component } from '@angular/core';
import { AllServicesService } from './services/all-services.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'surveyprojectv1';

  constructor() {
  }

}
